import { createContext, useContext, useEffect, useMemo, useState } from "react";

const AppContext = createContext(null);
const read = (key, fallback) => {
  try { return JSON.parse(localStorage.getItem(key)) ?? fallback; }
  catch { return fallback; }
};

export function AppProvider({ children }) {
  const [watchlist, setWatchlist] = useState(() => read("streambox-watchlist", []));
  const [user, setUser] = useState(() => read("streambox-user", null));

  useEffect(() => localStorage.setItem("streambox-watchlist", JSON.stringify(watchlist)), [watchlist]);
  useEffect(() => localStorage.setItem("streambox-user", JSON.stringify(user)), [user]);

  const toggleWatchlist = (movie) => setWatchlist(current =>
    current.some(item => item.id === movie.id)
      ? current.filter(item => item.id !== movie.id)
      : [...current, movie]
  );

  const value = useMemo(() => ({ watchlist, user, setUser, toggleWatchlist }), [watchlist, user]);
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export const useApp = () => useContext(AppContext);

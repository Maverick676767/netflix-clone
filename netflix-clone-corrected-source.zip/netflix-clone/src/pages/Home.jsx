import Hero from "../components/Hero";
import MovieRow from "../components/MovieRow";
import { movies } from "../data/movies";

export default function Home() {
  const featured = movies.find(movie => movie.featured) || movies[0];
  return <>
    <Hero movie={featured}/>
    <div className="home-rows">
      <MovieRow title="Trending Now" items={movies.slice(1, 9)}/>
      <MovieRow title="Popular on Netflix" items={[...movies].reverse().slice(0, 8)}/>
      <MovieRow title="Binge-worthy Series" items={movies.filter(movie => movie.type === "Series")}/>
      <MovieRow title="Only on Netflix" items={movies.slice(3, 11)}/>
    </div>
  </>;
}

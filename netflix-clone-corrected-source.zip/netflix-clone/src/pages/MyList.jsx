import { Link } from "react-router-dom";
import { Bookmark } from "lucide-react";
import MovieCard from "../components/MovieCard";
import { useApp } from "../context/AppContext";

export default function MyList() {
  const { watchlist } = useApp();
  return <main className="page-container">
    <div className="page-title-line"><h1>My List</h1><span className="page-subtitle">Your saved movies and series</span></div>
    {watchlist.length ? <div className="movie-grid">{watchlist.map(movie => <MovieCard key={movie.id} movie={movie}/>)}</div> :
      <div className="empty-state"><Bookmark size={42}/><h2>Your list is looking a little empty</h2><p>Add shows and movies you want to watch later.</p><Link to="/" className="button button-light">Explore titles</Link></div>}
  </main>;
}

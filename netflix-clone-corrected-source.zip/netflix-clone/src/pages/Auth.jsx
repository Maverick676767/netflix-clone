import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useApp } from "../context/AppContext";

export default function Auth({ mode = "login" }) {
  const isSignup = mode === "signup";
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();
  const { setUser } = useApp();

  const submit = (e) => {
    e.preventDefault();
    if (!email.includes("@") || password.length < 4 || (isSignup && !name.trim())) {
      setError("Please enter valid details. Password must be at least 4 characters for this demo.");
      return;
    }
    setUser({ name: name.trim() || email.split("@")[0], email });
    navigate("/");
  };

  return <main className="auth-page">
    <div className="auth-backdrop"/>
    <Link to="/" className="wordmark auth-logo">NETFLIX</Link>
    <form className="auth-card" onSubmit={submit}>
      <h1>{isSignup ? "Create Account" : "Sign In"}</h1>
      {isSignup && <input value={name} onChange={e => setName(e.target.value)} placeholder="Your name" aria-label="Name"/>}
      <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="Email or phone number" aria-label="Email" required/>
      <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Password" aria-label="Password" required/>
      {error && <p className="form-error">{error}</p>}
      <button className="auth-submit">{isSignup ? "Sign Up" : "Sign In"}</button>
      <div className="auth-options"><label><input type="checkbox" defaultChecked/> Remember me</label><a href="#help">Need help?</a></div>
      <p className="auth-switch">{isSignup ? "Already have an account?" : "New to Netflix?"} <Link to={isSignup ? "/login" : "/signup"}>{isSignup ? "Sign in now." : "Sign up now."}</Link></p>
      <p className="auth-small">This is an educational UI demo. Account details are stored only in this browser and are not sent to a server.</p>
    </form>
  </main>;
}

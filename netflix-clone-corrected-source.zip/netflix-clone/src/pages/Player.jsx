import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, Pause, Play, Volume2, Maximize, Settings, SkipForward } from "lucide-react";
import { movies } from "../data/movies";

export default function Player() {
  const { id } = useParams();
  const navigate = useNavigate();
  const movie = movies.find(item => item.id === Number(id));
  const [playing, setPlaying] = useState(false);
  if (!movie) return <div className="player-page"><button onClick={() => navigate("/")}>Back home</button></div>;
  return <main className="player-page" style={{ backgroundImage: `linear-gradient(0deg,rgba(0,0,0,.88),transparent 45%),url("${movie.backdrop}")` }}>
    <button className="player-back" onClick={() => navigate(-1)}><ArrowLeft/> Back</button>
    <div className="player-center"><button className="big-play" onClick={() => setPlaying(!playing)}>{playing ? <Pause fill="white"/> : <Play fill="white"/>}</button><h2>{playing ? "Preview playing" : "Ready to watch?"}</h2><p>{movie.title}</p><span className="demo-note">DEMO PLAYER INTERFACE · Connect your own licensed video source to enable playback.</span></div>
    <div className="player-controls"><button onClick={() => setPlaying(!playing)}>{playing ? <Pause/> : <Play/>}</button><div className="fake-progress"><span/></div><span>00:00 / {movie.duration}</span><button><Volume2/></button><button><Settings/></button><button><Maximize/></button></div>
  </main>;
}

import { useMemo, useState } from "react";
import { Sparkles, Shuffle } from "lucide-react";
import MovieCard from "../components/MovieCard";
import { moods, movies } from "../data/movies";

export default function MoodMix() {
  const [selected, setSelected] = useState("Happy");
  const [refresh, setRefresh] = useState(0);
  const recommendations = useMemo(() => {
    const matching = movies.filter(movie => movie.mood.includes(selected));
    const others = movies.filter(movie => !movie.mood.includes(selected));
    return [...matching, ...others].slice(refresh % 2 ? 1 : 0, (refresh % 2 ? 1 : 0) + 8);
  }, [selected, refresh]);
  const mood = moods.find(item => item.name === selected);
  return <main className="page-container mood-page">
    <div className="mood-intro"><div className="mood-kicker"><Sparkles size={16}/> YOUR PERSONAL MIX</div><h1>What's your mood today?</h1><p>Pick a feeling. We'll find something worth watching.</p></div>
    <div className="mood-grid">{moods.map(item => <button key={item.name} onClick={() => setSelected(item.name)} className={`mood-choice ${selected === item.name ? "active" : ""}`}><span>{item.emoji}</span><strong>{item.name}</strong></button>)}</div>
    <div className="mix-heading"><div><span className="mix-label">YOUR MOOD MIX</span><h2>{mood.emoji} {selected} picks</h2><p>{mood.subtitle}</p></div><button className="button button-muted" onClick={() => setRefresh(v => v + 1)}><Shuffle size={17}/> Mix it up</button></div>
    <div className="movie-grid">{recommendations.map(movie => <MovieCard key={movie.id} movie={movie}/>)}</div>
  </main>;
}

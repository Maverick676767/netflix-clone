import { Link, useParams, useNavigate } from "react-router-dom";
import { Play, Plus, Check, ArrowLeft } from "lucide-react";
import { movies } from "../data/movies";
import { useApp } from "../context/AppContext";
import MovieRow from "../components/MovieRow";

export default function Details() {
  const { id } = useParams();
  const navigate = useNavigate();
  const movie = movies.find(item => item.id === Number(id));
  const { watchlist, toggleWatchlist } = useApp();
  if (!movie) return <main className="page-container empty-state"><h2>Title not found</h2><button className="button button-light" onClick={() => navigate("/")}>Go home</button></main>;
  const saved = watchlist.some(item => item.id === movie.id);
  return <main className="details-page">
    <section className="details-hero" style={{ backgroundImage: `linear-gradient(0deg,#080808 0%,rgba(8,8,8,.2) 75%),linear-gradient(90deg,rgba(8,8,8,.82),transparent),url("${movie.backdrop}")` }}>
      <button className="back-button" onClick={() => navigate(-1)}><ArrowLeft size={18}/> Back</button>
      <div className="details-content"><span className="eyebrow"><span className="mini-n">N</span> FEATURED TITLE</span><h1>{movie.title}</h1>
        <div className="hero-meta"><span className="match">98% Match</span><span>{movie.year}</span><span className="maturity">{movie.rating}</span><span>{movie.duration}</span></div>
        <p>{movie.description}</p>
        <div className="hero-buttons"><Link to={`/watch/${movie.id}`} className="button button-light"><Play fill="currentColor"/> Play</Link><button onClick={() => toggleWatchlist(movie)} className="button button-muted">{saved ? <Check/> : <Plus/>} {saved ? "Added to My List" : "My List"}</button></div>
      </div>
    </section>
    <section className="details-lower"><div className="details-facts"><div><span className="fact-label">Genres</span><p>{movie.genre.join(", ")}</p></div><div><span className="fact-label">Type</span><p>{movie.type}</p></div><div><span className="fact-label">Release year</span><p>{movie.year}</p></div></div><MovieRow title="More Like This" items={movies.filter(item => item.id !== movie.id && item.genre.some(g => movie.genre.includes(g))).slice(0, 7)}/></section>
  </main>;
}

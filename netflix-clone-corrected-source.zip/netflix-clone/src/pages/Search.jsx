import { useMemo } from "react";
import { useSearchParams } from "react-router-dom";
import MovieCard from "../components/MovieCard";
import { movies } from "../data/movies";

export default function Search() {
  const [params, setParams] = useSearchParams();
  const query = params.get("q") || "";
  const results = useMemo(() => movies.filter(movie => `${movie.title} ${movie.genre.join(" ")} ${movie.description}`.toLowerCase().includes(query.toLowerCase())), [query]);
  return <main className="page-container">
    <div className="search-page-input"><input autoFocus value={query} onChange={e => setParams(e.target.value ? { q: e.target.value } : {})} placeholder="Search for a movie, show, genre..."/></div>
    <h1 className="search-heading">{query ? `Explore results for “${query}”` : "Explore titles"}</h1>
    {results.length ? <div className="movie-grid">{results.map(movie => <MovieCard key={movie.id} movie={movie}/>)}</div> : <div className="empty-state"><h2>No results found</h2><p>Try searching for a different title or genre.</p></div>}
  </main>;
}

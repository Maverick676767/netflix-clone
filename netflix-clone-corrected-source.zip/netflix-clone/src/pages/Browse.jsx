import { useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import MovieCard from "../components/MovieCard";
import { genres, movies } from "../data/movies";

export default function Browse({ type = "All" }) {
  const [genre, setGenre] = useState("All");
  const heading = type === "Series" ? "TV Shows" : type === "Movie" ? "Movies" : "Browse";
  const filtered = useMemo(() => movies.filter(movie =>
    (type === "All" || movie.type === type) &&
    (genre === "All" || movie.genre.includes(genre))
  ), [genre, type]);
  return <main className="page-container">
    <div className="page-title-line"><h1>{heading}</h1><span className="page-subtitle">Explore stories picked for you</span></div>
    <div className="genre-filter"><label htmlFor="genre-select">Genres</label><select id="genre-select" value={genre} onChange={e => setGenre(e.target.value)}>{genres.map(item => <option key={item}>{item}</option>)}</select></div>
    <div className="movie-grid">{filtered.map(movie => <MovieCard key={movie.id} movie={movie}/>)}</div>
    {!filtered.length && <p className="empty-state">No titles found in this category.</p>}
  </main>;
}

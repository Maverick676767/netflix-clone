import { useEffect } from "react";
import { Routes, Route, useLocation } from "react-router-dom";

import Home from "./pages/Home";
import Browse from "./pages/Browse";
import Search from "./pages/Search";
import MyList from "./pages/MyList";
import MoodMix from "./pages/MoodMix";
import Details from "./pages/Details";
import Player from "./pages/Player";
import Auth from "./pages/Auth";

import Navbar from "./components/Navbar";
import Footer from "./components/Footer";

function ScrollToTop() {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: "auto" });
  }, [pathname]);

  return null;
}

export default function App() {
  const location = useLocation();
  const isAuthPage = location.pathname === "/login" || location.pathname === "/signup";

  return (
    <>
      <ScrollToTop />
      {!isAuthPage && <Navbar />}
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/browse" element={<Browse type="All" />} />
        <Route path="/series" element={<Browse type="Series" />} />
        <Route path="/movies" element={<Browse type="Movie" />} />
        <Route path="/search" element={<Search />} />
        <Route path="/my-list" element={<MyList />} />
        <Route path="/mood-mix" element={<MoodMix />} />
        <Route path="/title/:id" element={<Details />} />
        <Route path="/movie/:id" element={<Details />} />
        <Route path="/watch/:id" element={<Player />} />
        <Route path="/login" element={<Auth mode="login" />} />
        <Route path="/signup" element={<Auth mode="signup" />} />
        <Route path="*" element={<Home />} />
      </Routes>
      {!isAuthPage && <Footer />}
    </>
  );
}

import { Github, Instagram, Youtube } from "lucide-react";
export default function Footer() {
  return <footer className="footer">
    <div className="footer-social"><a href="https://github.com" aria-label="GitHub"><Github/></a><a href="https://instagram.com" aria-label="Instagram"><Instagram/></a><a href="https://youtube.com" aria-label="YouTube"><Youtube/></a></div>
    <div className="footer-links"><a href="#audio">Audio Description</a><a href="#help">Help Centre</a><a href="#gift">Gift Cards</a><a href="#media">Media Centre</a><a href="#jobs">Jobs</a><a href="#terms">Terms of Use</a><a href="#privacy">Privacy</a><a href="#legal">Legal Notices</a></div>
    <span className="service-code">Service Code</span>
    <p>© 2026 Streambox UI Project · Built for educational purposes</p>
  </footer>;
}

import { ChevronLeft, ChevronRight } from "lucide-react";
import { useRef } from "react";
import MovieCard from "./MovieCard";

export default function MovieRow({ title, items }) {
  const track = useRef(null);
  if (!items?.length) return null;
  const scroll = (direction) => track.current?.scrollBy({ left: direction * track.current.clientWidth * 0.78, behavior: "smooth" });
  return (
    <section className="movie-row">
      <div className="row-heading"><h2>{title}</h2></div>
      <div className="row-shell">
        <button className="row-arrow left" onClick={() => scroll(-1)} aria-label="Scroll left"><ChevronLeft/></button>
        <div className="movie-track" ref={track}>{items.map(movie => <MovieCard key={movie.id} movie={movie}/>)}</div>
        <button className="row-arrow right" onClick={() => scroll(1)} aria-label="Scroll right"><ChevronRight/></button>
      </div>
    </section>
  );
}

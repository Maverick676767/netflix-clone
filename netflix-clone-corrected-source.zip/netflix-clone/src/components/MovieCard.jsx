import { Link } from "react-router-dom";
import { Play, Plus, Check, Info } from "lucide-react";
import { useApp } from "../context/AppContext";

export default function MovieCard({ movie }) {
  const { watchlist, toggleWatchlist } = useApp();
  const saved = watchlist.some(item => item.id === movie.id);
  return (
    <article className="movie-card">
      <Link to={`/title/${movie.id}`} className="poster-link">
        <img src={movie.poster} alt={movie.title} loading="lazy" onError={e => { e.currentTarget.src = "https://placehold.co/500x750/171717/eeeeee?text=NETFLIX"; }} />
      </Link>
      <div className="card-info">
        <div className="card-actions">
          <Link to={`/watch/${movie.id}`} className="round-action play-action" aria-label={`Play ${movie.title}`}><Play size={16} fill="currentColor"/></Link>
          <button className={`round-action ${saved ? "saved" : ""}`} onClick={() => toggleWatchlist(movie)} aria-label="Add to My List">{saved ? <Check size={16}/> : <Plus size={17}/>}</button>
          <Link to={`/title/${movie.id}`} className="round-action info-action" aria-label="More information"><Info size={16}/></Link>
        </div>
        <Link to={`/title/${movie.id}`} className="card-title">{movie.title}</Link>
        <div className="card-meta"><span className="match">98% Match</span><span>{movie.year}</span><span className="maturity">{movie.rating}</span></div>
        <p className="card-genres">{movie.genre.join(" · ")}</p>
      </div>
    </article>
  );
}

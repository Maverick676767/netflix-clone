import { useState } from "react";
import { Link, NavLink, useNavigate } from "react-router-dom";
import { Bell, Search, ChevronDown, Menu, X } from "lucide-react";
import { useApp } from "../context/AppContext";

export default function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState("");
  const navigate = useNavigate();
  const { user } = useApp();

  const submitSearch = (e) => {
    e.preventDefault();
    navigate(`/search?q=${encodeURIComponent(query)}`);
    setSearchOpen(false);
    setMenuOpen(false);
  };

  return (
    <header className="navbar">
      <div className="nav-inner">
        <button className="mobile-menu icon-button" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle menu">
          {menuOpen ? <X /> : <Menu />}
        </button>
        <Link to="/" className="wordmark">NETFLIX</Link>
        <nav className={`nav-links ${menuOpen ? "nav-open" : ""}`}>
          <NavLink to="/" end onClick={() => setMenuOpen(false)}>Home</NavLink>
          <NavLink to="/series" onClick={() => setMenuOpen(false)}>TV Shows</NavLink>
          <NavLink to="/movies" onClick={() => setMenuOpen(false)}>Movies</NavLink>
          <NavLink to="/mood-mix" onClick={() => setMenuOpen(false)}>Mood Mix <span className="new-pill">NEW</span></NavLink>
          <NavLink to="/my-list" onClick={() => setMenuOpen(false)}>My List</NavLink>
        </nav>
        <div className="nav-actions">
          {searchOpen ? (
            <form className="nav-search" onSubmit={submitSearch}>
              <Search size={17} />
              <input autoFocus value={query} onChange={e => setQuery(e.target.value)} placeholder="Titles, people, genres" />
              <button type="button" className="plain-icon" onClick={() => setSearchOpen(false)}><X size={16}/></button>
            </form>
          ) : <button className="icon-button" aria-label="Search" onClick={() => setSearchOpen(true)}><Search /></button>}
          <button className="icon-button notification-button" aria-label="Notifications"><Bell /></button>
          <Link to="/login" className="profile-wrap" title={user?.name || "Sign in"}>
            <span className="profile-avatar">{user?.name?.[0]?.toUpperCase() || "A"}</span>
            <ChevronDown size={15} />
          </Link>
        </div>
      </div>
    </header>
  );
}

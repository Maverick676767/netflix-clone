import { Info, Play, Plus, Check } from "lucide-react";
import { Link } from "react-router-dom";
import { useApp } from "../context/AppContext";

export default function Hero({ movie }) {
  const { watchlist, toggleWatchlist } = useApp();
  const saved = watchlist.some(item => item.id === movie.id);
  return (
    <section className="hero" style={{ backgroundImage: `linear-gradient(90deg, #080808 0%, rgba(8,8,8,.78) 34%, rgba(8,8,8,.12) 76%), linear-gradient(0deg,#080808 0%,transparent 42%), url("${movie.backdrop}")` }}>
      <div className="hero-content">
        <div className="eyebrow"><span className="mini-n">N</span> SERIES</div>
        <h1>{movie.title}</h1>
        <div className="hero-meta"><span className="match">98% Match</span><span>{movie.year}</span><span className="maturity">{movie.rating}</span><span>{movie.duration}</span></div>
        <p>{movie.description}</p>
        <div className="hero-buttons">
          <Link to={`/watch/${movie.id}`} className="button button-light"><Play fill="currentColor" size={20}/> Play</Link>
          <Link to={`/title/${movie.id}`} className="button button-muted"><Info size={20}/> More Info</Link>
          <button onClick={() => toggleWatchlist(movie)} className="button button-outline">{saved ? <Check/> : <Plus/>} {saved ? "My List" : "Add to My List"}</button>
        </div>
      </div>
      <div className="hero-age"><span>{movie.rating}</span></div>
    </section>
  );
}
